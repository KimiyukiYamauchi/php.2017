//トグルボタン
jQuery(function(){
	jQuery("#navbtn").click(function(){
		jQuery("#mainmenu").slideToggle();
	});
});
