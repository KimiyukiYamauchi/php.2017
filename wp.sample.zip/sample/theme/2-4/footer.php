
<footer>
	<div class="copyright">
	<p><?php bloginfo( 'description' ); ?></p>
	<p>Copyright &copy; <?php bloginfo( 'name' ); ?></p>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
