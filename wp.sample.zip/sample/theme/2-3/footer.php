
<footer>
FOOTER
</footer>

<?php wp_footer(); ?>
</body>
</html>
