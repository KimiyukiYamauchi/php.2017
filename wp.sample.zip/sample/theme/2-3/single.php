<?php get_header(); ?>

<div class="contents">
CONTENTS
</div>

<div class="sub">
SIDEBAR
</div>

<?php get_footer(); ?>
