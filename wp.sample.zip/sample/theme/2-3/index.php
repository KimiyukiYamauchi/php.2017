<?php get_header(); ?>

<div class="container">
<div class="contents">
CONTENTS
</div>

<div class="sub">
SIDEBAR
</div>
</div>

<?php get_footer(); ?>
